package com.team4.ishaq.galgotech;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

Set content view from xml for Activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}



public class appTest extends Activity {
    private EditText urlText;
    private Button goButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Get a handle to all user interface elements
        urlText = (EditText) findViewById(R.id.url_field);
        goButton = (Button) findViewById(R.id.go_button);

        // Setup event handlers
        goButton.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                openBrowser();
            }
        });
        urlText.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    openBrowser();
                    return true;
                }
                return false;
            }
        });
    }

    /** Open a browser on the URL specified in the text box */
    private void openBrowser() {
        Uri uri = Uri.parse(urlText.getText().toString());
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

}

// main.xml

    <?xml version="1.0" encoding="utf-8"?>
<LinearLayout
xmlns:android="http://schemas.android.com/apk/res/android"
        android:orientation="vertical"
        android:layout_width="fill_parent"
        android:layout_height="fill_parent">
<LinearLayout
android:orientation="horizontal"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content">
<EditText
android:id="@+id/url_field"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_weight="1.0"
        android:lines="1" />
<Button
android:id="@+id/go_button"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/go_button" />
</LinearLayout>
<WebView
android:id="@+id/web_view"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content"
        android:layout_weight="1.0" />
</LinearLayout>




public class appTest extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        LinearLayout bkgr = (LinearLayout) findViewById(R.id.uilayout);
        final ImageView image = (ImageView) findViewById(R.id.ImageView01);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Pick an Image!")
                .setMessage("Please Select Image One or Image Two:")
                .setCancelable(false)
                .setPositiveButton("IMAGE 1",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                image.setImageResource(R.drawable.image1);
                            }
                        })

                .setNegativeButton("IMAGE 2",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                image.setImageResource(R.drawable.image2);
                            }
                        });

        switch (item.getItemId()) {
            case R.id.buttonone:
                image.setImageResource(R.drawable.image1);
                return true;
            case R.id.buttontwo:
                image.setImageResource(R.drawable.image2);
                return true;
            case R.id.buttonthree:
                bkgr.setBackgroundResource(R.color.background2);
                return true;
            case R.id.buttonfour:
                bkgr.setBackgroundResource(R.color.background);
                return true;
            case R.id.buttonfive:
                builder.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}public class appTest extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        LinearLayout bkgr = (LinearLayout) findViewById(R.id.uilayout);
        final ImageView image = (ImageView) findViewById(R.id.ImageView01);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Pick an Image!")
                .setMessage("Please Select Image One or Image Two:")
                .setCancelable(false)
                .setPositiveButton("IMAGE 1",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                image.setImageResource(R.drawable.image1);
                            }
                        })

                .setNegativeButton("IMAGE 2",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                image.setImageResource(R.drawable.image2);
                            }
                        });

        switch (item.getItemId()) {
            case R.id.buttonone:
                image.setImageResource(R.drawable.image1);
                return true;
            case R.id.buttontwo:
                image.setImageResource(R.drawable.image2);
                return true;
            case R.id.buttonthree:
                bkgr.setBackgroundResource(R.color.background2);
                return true;
            case R.id.buttonfour:
                bkgr.setBackgroundResource(R.color.background);
                return true;
            case R.id.buttonfive:
                builder.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}public class appTest extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        LinearLayout bkgr = (LinearLayout) findViewById(R.id.uilayout);
        final ImageView image = (ImageView) findViewById(R.id.ImageView01);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Pick an Image!")
                .setMessage("Please Select Image One or Image Two:")
                .setCancelable(false)
                .setPositiveButton("IMAGE 1",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                image.setImageResource(R.drawable.image1);
                            }
                        })

                .setNegativeButton("IMAGE 2",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                image.setImageResource(R.drawable.image2);
                            }
                        });

        switch (item.getItemId()) {
            case R.id.buttonone:
                image.setImageResource(R.drawable.image1);
                return true;
            case R.id.buttontwo:
                image.setImageResource(R.drawable.image2);
                return true;
            case R.id.buttonthree:
                bkgr.setBackgroundResource(R.color.background2);
                return true;
            case R.id.buttonfour:
                bkgr.setBackgroundResource(R.color.background);
                return true;
            case R.id.buttonfive:
                builder.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}public class appTest extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        LinearLayout bkgr = (LinearLayout) findViewById(R.id.uilayout);
        final ImageView image = (ImageView) findViewById(R.id.ImageView01);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Pick an Image!")
                .setMessage("Please Select Image One or Image Two:")
                .setCancelable(false)
                .setPositiveButton("IMAGE 1",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                image.setImageResource(R.drawable.image1);
                            }
                        })

                .setNegativeButton("IMAGE 2",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                image.setImageResource(R.drawable.image2);
                            }
                        });

        switch (item.getItemId()) {
            case R.id.buttonone:
                image.setImageResource(R.drawable.image1);
                return true;
            case R.id.buttontwo:
                image.setImageResource(R.drawable.image2);
                return true;
            case R.id.buttonthree:
                bkgr.setBackgroundResource(R.color.background2);
                return true;
            case R.id.buttonfour:
                bkgr.setBackgroundResource(R.color.background);
                return true;
            case R.id.buttonfive:
                builder.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}













